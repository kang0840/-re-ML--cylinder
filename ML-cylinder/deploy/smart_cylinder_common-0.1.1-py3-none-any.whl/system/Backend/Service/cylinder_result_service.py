"""Application service for sensor collection and completed analysis cycles."""

import os

from typing import Any

from system.DB.Supabase.cylinder_result_repository import (
    CylinderResultRepository,
    RepositoryConfigurationError,
    RepositoryWriteError,
    SessionConflictError,
)

COLLECTION_MODES = ("TRAINING", "OPERATION", "TEST")


class ResultStorageUnavailableError(RuntimeError):
    """Raised when server-only Supabase credentials are unavailable."""


class CollectionModeError(RuntimeError):
    """Raised when collection mode cannot safely classify a message."""


def resolve_collection_route(collection_mode: str, cylinder_id: str) -> dict[str, Any]:
    """Resolve dataset meaning from both collection mode and cylinder identity."""
    if collection_mode not in COLLECTION_MODES:
        raise CollectionModeError(
            "COLLECTION_MODE must be TRAINING, OPERATION, or TEST"
        )
    if collection_mode == "TRAINING":
        if cylinder_id == "cylinder_01":
            return {
                "collection_mode": "TRAINING",
                "dataset_type": "TRAINING_ABNORMAL",
                "ground_truth": "SEAL_LEAK",
                "ground_truth_source": "MANUAL_EXPERIMENT",
            }
        if cylinder_id == "cylinder_02":
            return {
                "collection_mode": "TRAINING",
                "dataset_type": "TRAINING_NORMAL",
                "ground_truth": "NORMAL",
                "ground_truth_source": "MANUAL_EXPERIMENT",
            }
        raise CollectionModeError(
            "TRAINING mode accepts only cylinder_01 and cylinder_02"
        )
    if collection_mode == "TEST":
        return {
            "collection_mode": "TEST",
            "dataset_type": "TEST",
            "ground_truth": None,
            "ground_truth_source": None,
        }
    return {
        "collection_mode": "OPERATION",
        "dataset_type": "RAW_OPERATION",
        "ground_truth": None,
        "ground_truth_source": None,
    }


class CylinderResultService:
    """Coordinate result persistence without owning HTTP or database details."""

    def __init__(self, repository: CylinderResultRepository | None = None) -> None:
        self._repository = repository or CylinderResultRepository()

    def record_sensor_message(
        self,
        payload: dict[str, Any],
        is_duplicate: bool = False,
        collection_mode: str | None = None,
        experiment_id: str | None = None,
    ) -> dict[str, Any] | None:
        """Store one Parser-approved MQTT message under an explicit collection mode."""
        if is_duplicate:
            return None
        selected_mode = collection_mode or os.environ.get("COLLECTION_MODE")
        if selected_mode is None:
            raise CollectionModeError("COLLECTION_MODE is required")
        route = resolve_collection_route(selected_mode, payload["cylinder_id"])
        session = {
            "session_id": payload["session_id"],
            "cylinder_id": payload["cylinder_id"],
            "started_at": payload["timestamp"],
            "experiment_id": experiment_id,
            **route,
        }
        try:
            self._repository.ensure_collection_session(session)
            return self._repository.save_raw_data(payload)
        except RepositoryConfigurationError as error:
            raise ResultStorageUnavailableError(str(error)) from error
        except (RepositoryWriteError, SessionConflictError) as error:
            raise RuntimeError("failed to store collection message") from error

    def record_cycle_result(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Pass session-linked feature and prediction data to the repository."""
        try:
            return self._repository.save_processed_features_and_ml_result(payload)
        except RepositoryConfigurationError as error:
            raise ResultStorageUnavailableError(str(error)) from error
        except RepositoryWriteError as error:
            raise RuntimeError("failed to store cylinder result") from error

    def load_training_dataset(self) -> list[dict[str, Any]]:
        """Return features that belong to validated labelled training sessions."""
        try:
            return self._repository.load_training_dataset()
        except RepositoryConfigurationError as error:
            raise ResultStorageUnavailableError(str(error)) from error
        except RepositoryWriteError as error:
            raise RuntimeError("failed to load training dataset") from error
