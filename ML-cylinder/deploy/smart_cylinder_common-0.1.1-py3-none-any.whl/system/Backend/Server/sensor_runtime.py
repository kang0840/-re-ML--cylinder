"""Pi orchestration; signal processing remains in the injected ML interface."""

import argparse
import importlib
import os
import threading
from copy import deepcopy
from dataclasses import dataclass

from system.MQTT.subscriber import DuplicateTracker, MqttSubscriber
from system.MQTT.message_parser import parse_payload
from system.Sensor.cycle_detector import CycleChunkBuffer, CycleProcessingCoordinator
from system.ML.Condition.analysis import CycleFeatureExtractor, make_backend_result


@dataclass(frozen=True)
class STFTConfig:
    window_size: int
    hop_length: int
    n_fft: int
    window_function: str
    similarity_threshold: float

    def __post_init__(self):
        for value in (self.window_size, self.hop_length, self.n_fft):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError("STFT sizes must be positive integers")
        if self.hop_length > self.window_size or self.n_fft < self.window_size:
            raise ValueError("inconsistent STFT sizes")
        if not self.window_function:
            raise ValueError("window_function is required")
        from math import isfinite

        if not isfinite(self.similarity_threshold):
            raise ValueError("similarity_threshold must be finite")


class StorageDuplicateTracker(DuplicateTracker):
    """Acknowledge an identity only after the callback persisted its raw data."""

    def record(self, payload):
        return payload["duplicate_key"] in self._messages

    def acknowledge(self, payload):
        super().record(payload)


class SensorRuntime:
    """Join existing parser, Cycle, ML and Service without making policy choices.

    stft_detector.detect(chunks, config) returns a continuous (start, end)
    interval in seconds, or None. condition_predictor(features, model_features)
    returns the existing NORMAL/ABNORMAL/ready contract. Both are externally
    supplied ML adapters, not implementations in this orchestration module.
    """

    def __init__(
        self,
        service,
        collection_mode,
        detector_factory=None,
        max_cycle_chunks=None,
        stft_config=None,
        stft_detector=None,
        condition_predictor=None,
        feature_extractor=None,
    ):
        from system.Backend.Service.cylinder_result_service import COLLECTION_MODES

        if collection_mode not in COLLECTION_MODES:
            raise ValueError("CONFIG_REQUIRED: COLLECTION_MODE")
        self.service = service
        self.collection_mode = collection_mode
        self.detector_factory = detector_factory
        self.max_cycle_chunks = max_cycle_chunks
        self.stft_config = stft_config
        self.stft_detector = stft_detector
        self.condition_predictor = condition_predictor
        self.extractor = feature_extractor
        self._cycles = {}
        self._sessions = {}
        self._lock = threading.RLock()
        self._tracker = StorageDuplicateTracker()
        self.subscriber = MqttSubscriber(self._receive, self._tracker)
        self.status = "READY" if not self.missing_config else "CONFIG_REQUIRED"
        self.last_error = None
        self.last_result = None

    @property
    def missing_config(self):
        return [
            name
            for name in (
                "detector_factory",
                "max_cycle_chunks",
                "stft_config",
                "stft_detector",
                "condition_predictor",
            )
            if getattr(self, name) is None
        ]

    def handle_message(self, raw_payload, topic=None):
        """Validate topic and payload; isolate errors without logging credentials."""
        with self._lock:
            try:
                if topic is not None:
                    parsed = parse_payload(deepcopy(raw_payload))
                    if topic != "smart-cylinder/%s/sensor" % parsed["cylinder_id"]:
                        raise ValueError("topic identity mismatch")
                    raw_payload = parsed
                return self.subscriber.handle_message(deepcopy(raw_payload))
            except Exception as error:
                self.status = "INPUT_OR_STORAGE_FAILED"
                self.last_error = type(error).__name__
                return None

    def _receive(self, payload, is_duplicate):
        self.service.record_sensor_message(
            payload, is_duplicate=is_duplicate, collection_mode=self.collection_mode
        )
        self._tracker.acknowledge(payload)
        self.last_error = None
        cylinder = payload["cylinder_id"]
        session = payload["session_id"]
        if self._sessions.get(cylinder) != session:
            self._cycles.pop(cylinder, None)
            self._sessions[cylinder] = session
        if self.missing_config:
            self.status = "CONFIG_REQUIRED"
            return
        self.status = "READY"
        if cylinder not in self._cycles:
            self._cycles[cylinder] = CycleProcessingCoordinator(
                self.detector_factory(cylinder),
                CycleChunkBuffer(self.max_cycle_chunks),
                self._completed,
            )
        self._cycles[cylinder].receive_sensor_chunk(payload)

    def update_distances(self, cylinder_id, distances_cm):
        with self._lock:
            if cylinder_id not in self._cycles:
                return []
            try:
                return self._cycles[cylinder_id].update_distances(distances_cm)
            except Exception as error:
                self.status = "CYCLE_FAILED"
                self.last_error = type(error).__name__
                return []

    def _completed(self, cycle_id, chunks, reason):
        if reason != "completed" or not chunks:
            self.status = "CYCLE_INCOMPLETE"
            return
        identities = {(p["cylinder_id"], p["session_id"]) for p in chunks}
        sequences = [p["sequence_id"] for p in chunks]
        if len(identities) != 1 or any(
            b != a + 1 for a, b in zip(sequences, sequences[1:])
        ):
            self.status = "CYCLE_INCOMPLETE"
            return
        interval = self.stft_detector.detect(chunks, self.stft_config)
        if interval is None:
            self.status = "NO_MOTION_SOUND"
            return
        import math

        start, end = interval
        if not all(math.isfinite(v) for v in interval) or start < 0 or end <= start:
            raise ValueError("invalid STFT interval")
        samples = {}
        for sensor, rate in (("sph0645", 4000), ("inmp441", 16000)):
            values = [s for p in chunks for s in p[sensor]["samples"]]
            if end > len(values) / rate:
                raise ValueError("STFT interval exceeds captured audio")
            selected = values[math.ceil(start * rate) : math.floor(end * rate)]
            if len(selected) < 2:
                raise ValueError("STFT interval has insufficient samples")
            samples[sensor] = selected
        extractor = self.extractor or CycleFeatureExtractor()
        model_features = extractor.extract_model_features(
            samples["sph0645"], samples["inmp441"]
        )
        features = extractor.extract(samples["sph0645"], samples["inmp441"])
        condition = self.condition_predictor(features, model_features)
        if not condition.get("ready", False):
            self.status = "MODEL_REQUIRED"
            return
        first = chunks[0]
        result = make_backend_result(
            first["cylinder_id"],
            first["session_id"],
            cycle_id,
            first["timestamp"],
            features,
            condition,
        )
        self.service.record_cycle_result(result)
        self.last_result = result
        self.status = "STORED"


def main():
    """Use an existing external factory for policies and HC-SR04 scheduling."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--factory", help="trusted installed module:function")
    args = parser.parse_args()
    if not args.factory or not os.environ.get("COLLECTION_MODE"):
        print("CONFIG_REQUIRED: --factory and COLLECTION_MODE")
        return 2
    module, name = args.factory.split(":", 1)
    runtime = getattr(importlib.import_module(module), name)()
    if runtime.missing_config:
        print("CONFIG_REQUIRED: " + ", ".join(runtime.missing_config))
        return 2
    from system.MQTT.client import PiMqttClient
    import paho.mqtt.client as mqtt

    password = os.environ.get("MQTT_PASSWORD")
    if not password:
        print("CONFIG_REQUIRED: MQTT_PASSWORD")
        return 2
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    connection = PiMqttClient(client, subscriber=runtime, password=password)

    def on_connect(_client, _userdata, _flags, reason, _properties):
        if reason == 0:
            connection.on_reconnect()

    client.on_connect = on_connect
    connection.connect_and_subscribe()
    try:
        client.loop_forever()
    finally:
        client.disconnect()


if __name__ == "__main__":
    raise SystemExit(main())
