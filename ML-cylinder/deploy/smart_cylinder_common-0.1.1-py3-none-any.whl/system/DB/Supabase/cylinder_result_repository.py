"""Supabase repository for collection sessions, raw data, and cycle results."""

import os
from datetime import datetime, timezone
from typing import Any

from supabase import Client, create_client


class RepositoryConfigurationError(RuntimeError):
    """Raised when the server-only Supabase credentials are unavailable."""


class RepositoryWriteError(RuntimeError):
    """Raised when Supabase rejects a persistence request."""


class SessionConflictError(RuntimeError):
    """Raised when an existing session has different collection semantics."""


class CylinderResultRepository:
    """Persistence boundary for collection data and analysis results."""

    def __init__(self, client: Client | None = None) -> None:
        self._client = client

    def ensure_collection_session(self, session: dict[str, Any]) -> dict[str, Any]:
        """Create one immutable semantic record for a Pico session."""
        client = self._get_client()
        session_row = {
            "session_id": session["session_id"],
            "cylinder_id": session["cylinder_id"],
            "collection_mode": session["collection_mode"],
            "dataset_type": session["dataset_type"],
            "ground_truth": session.get("ground_truth"),
            "ground_truth_source": session.get("ground_truth_source"),
            "experiment_id": session.get("experiment_id"),
            "started_at": session["started_at"],
        }

        try:
            client.table("collection_sessions").upsert(
                session_row,
                on_conflict="session_id",
                ignore_duplicates=True,
            ).execute()
            response = (
                client.table("collection_sessions")
                .select(
                    "session_id,cylinder_id,collection_mode,dataset_type,"
                    "ground_truth,ground_truth_source,experiment_id,started_at"
                )
                .eq("session_id", session["session_id"])
                .limit(1)
                .execute()
            )
        except Exception as error:
            raise RepositoryWriteError("Supabase session write failed") from error

        rows = response.data or []
        if not rows:
            raise RepositoryWriteError("Supabase session write was not confirmed")
        stored = rows[0]
        semantic_fields = (
            "cylinder_id",
            "collection_mode",
            "dataset_type",
            "ground_truth",
            "ground_truth_source",
            "experiment_id",
        )
        if any(stored.get(name) != session_row.get(name) for name in semantic_fields):
            raise SessionConflictError(
                "session_id is already registered with different collection semantics"
            )
        return stored

    def save_raw_data(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Upsert one parsed MQTT message by the approved QoS 1 identity."""
        client = self._get_client()
        updated_at = datetime.now(timezone.utc).isoformat()
        raw_row = {
            "cylinder_id": payload["cylinder_id"],
            "session_id": payload["session_id"],
            "sequence_id": payload["sequence_id"],
            "cycle_id": payload.get("cycle_id"),
            "measured_at": payload["timestamp"],
            "raw_payload": self._compact_raw_payload(payload),
            "updated_at": updated_at,
        }
        try:
            client.table("raw_data").upsert(
                raw_row,
                on_conflict="cylinder_id,session_id,sequence_id",
            ).execute()
        except Exception as error:
            raise RepositoryWriteError("Supabase raw-data write failed") from error
        return {
            "cylinder_id": payload["cylinder_id"],
            "session_id": payload["session_id"],
            "sequence_id": payload["sequence_id"],
        }

    def save_processed_features_and_ml_result(
        self, payload: dict[str, Any]
    ) -> dict[str, Any]:
        """Upsert Cycle features first, then the related ML result."""
        client = self._get_client()
        updated_at = datetime.now(timezone.utc).isoformat()
        features = payload.get("features") or {}
        feature_row = {
            "cylinder_id": payload["cylinder_id"],
            "cycle_id": payload["cycle_id"],
            "session_id": payload["session_id"],
            "measured_at": payload["timestamp"],
            "sph0645_rms": features.get("sph0645_rms"),
            "inmp441_rms": features.get("inmp441_rms"),
            "sph0645_peak": features.get("sph0645_peak"),
            "inmp441_peak": features.get("inmp441_peak"),
            "sph0645_peak_to_peak": features.get("sph0645_peak_to_peak"),
            "inmp441_peak_to_peak": features.get("inmp441_peak_to_peak"),
            "sph0645_crest_factor": features.get("sph0645_crest_factor"),
            "inmp441_crest_factor": features.get("inmp441_crest_factor"),
            "fft_features": features.get("fft_features"),
            "updated_at": updated_at,
        }
        result_row = {
            "cylinder_id": payload["cylinder_id"],
            "cycle_id": payload["cycle_id"],
            "measured_at": payload["timestamp"],
            "prediction": payload["prediction"],
            "leakage_score": payload.get("leakage_score"),
            "updated_at": updated_at,
        }

        try:
            client.table("processed_features").upsert(
                feature_row,
                on_conflict="cylinder_id,cycle_id",
            ).execute()
            client.table("ml_results").upsert(
                result_row,
                on_conflict="cylinder_id,cycle_id",
            ).execute()
        except Exception as error:
            raise RepositoryWriteError("Supabase write failed") from error

        return {
            "cylinder_id": payload["cylinder_id"],
            "cycle_id": payload["cycle_id"],
            "session_id": payload["session_id"],
        }

    def load_training_dataset(self) -> list[dict[str, Any]]:
        """Load only explicitly labelled TRAINING feature rows."""
        client = self._get_client()
        try:
            session_response = (
                client.table("collection_sessions")
                .select("session_id,dataset_type,ground_truth")
                .eq("collection_mode", "TRAINING")
                .in_(
                    "dataset_type",
                    ("TRAINING_NORMAL", "TRAINING_ABNORMAL"),
                )
                .execute()
            )
            sessions = {
                row["session_id"]: row
                for row in (session_response.data or [])
                if self._is_valid_training_session(row)
            }
            if not sessions:
                return []
            feature_response = (
                client.table("processed_features")
                .select("*")
                .in_("session_id", tuple(sessions))
                .execute()
            )
        except Exception as error:
            raise RepositoryWriteError("Supabase training-data read failed") from error

        dataset = []
        for feature_row in feature_response.data or []:
            session = sessions.get(feature_row.get("session_id"))
            if session is None:
                continue
            row = dict(feature_row)
            row["dataset_type"] = session["dataset_type"]
            row["ground_truth"] = session["ground_truth"]
            dataset.append(row)
        return dataset

    @staticmethod
    def _compact_raw_payload(payload: dict[str, Any]) -> dict[str, Any]:
        raw_payload = {
            name: value
            for name, value in payload.items()
            if name not in {"duplicate_key", "cycle_id"}
        }
        for sensor_name in ("sph0645", "inmp441"):
            chunk = raw_payload.get(sensor_name)
            if isinstance(chunk, dict):
                raw_payload[sensor_name] = {
                    name: value for name, value in chunk.items() if name != "samples"
                }
        return raw_payload

    @staticmethod
    def _is_valid_training_session(row: dict[str, Any]) -> bool:
        return (
            row.get("dataset_type") == "TRAINING_NORMAL"
            and row.get("ground_truth") == "NORMAL"
        ) or (
            row.get("dataset_type") == "TRAINING_ABNORMAL"
            and row.get("ground_truth") == "SEAL_LEAK"
        )

    def _get_client(self) -> Client:
        if self._client is not None:
            return self._client

        supabase_url = os.environ.get("SUPABASE_URL")
        service_role_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
        if not supabase_url or not service_role_key:
            raise RepositoryConfigurationError(
                "Supabase server credentials are not configured"
            )

        self._client = create_client(supabase_url, service_role_key)
        return self._client
