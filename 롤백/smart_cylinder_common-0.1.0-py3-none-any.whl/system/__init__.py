"""Single development source for the smart-cylinder-common distribution."""

__version__ = "0.1.0"
CANONICAL_PACKAGE = "smart-cylinder-common"
